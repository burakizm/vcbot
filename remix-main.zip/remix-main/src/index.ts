import userbot from "./userbot";
import bot from "./bot";

Promise.all([userbot(), bot()]);
